export BASE=`dirname $0`/..
export CONFIG_BASE="$BASE/config-files/META-INF"; 

echo "PATH: BASE=$BASE, CONFIG_BASE=$CONFIG_BASE"

